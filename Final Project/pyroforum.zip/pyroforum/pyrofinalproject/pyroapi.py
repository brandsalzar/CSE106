from flask import Flask, render_template, redirect,url_for,flash,request,abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin,LoginManager, login_required, logout_user, login_user,current_user
from flask_admin import Admin
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, TextAreaField
from wtforms.validators import InputRequired,length,ValidationError,DataRequired
from flask_bcrypt import Bcrypt
from datetime import datetime



app = Flask(__name__)
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
app.config["SQLALCHEMY_DATABASE_URI"] = 'sqlite:///pyro.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY']='keep it secret, keep it safe'

admin = Admin(app)

#Allows flask and login to work together
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

#Use to reload object for user id in session
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    password = db.Column(db.String(80), unique=False, nullable=False)
    posts = db.relationship('Post', backref='author', lazy=True)

    def __repr__(self):
        return f"User('{self.username}')"

class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    title = db.Column(db.String(40), nullable=False)
    date_posted = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    content = db.Column(db.Text, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

    def __repr__(self):
        return f"Post('{self.title}', '{self.date_posted}')"

class RegisterForm(FlaskForm):
    username = StringField(validators=[InputRequired(), length(min=4, max=15)],render_kw={"placeholder": "Enter Username"})
    password = PasswordField(validators=[InputRequired(), length(min=8, max=20)],render_kw={"placeholder": "Enter Password"})
    submit = SubmitField("Register")

    def validate_username(self,username):
        existing_user = User.query.filter_by(username=username.data).first()
        if existing_user:
            flash("Username already exists",'failure')
            raise ValidationError()

class LoginForm(FlaskForm):
    username = StringField(validators=[InputRequired(), length(min=4,max=15)], render_kw={"placeholder": "Username"})
    password = PasswordField(validators=[InputRequired(),length(min=8,max=20)], render_kw={"placeholder": "Password"})
    submit = SubmitField("Login")

class PostForm(FlaskForm):
    title = StringField('Title',validators=[DataRequired()])
    content = TextAreaField('Content',validators=[DataRequired()])
    submit = SubmitField("Post")

@app.route('/')
def home():
    return render_template('forums.html')

@app.route('/posts')
def posts():
    return render_template('posts.html')

@app.route('/comments')
def comment():
    return render_template('detail.html')


@app.route('/dashboard')
@login_required
def dash():

    posts = Post.query.all
    return render_template('dashboard.html',posts=posts)


@app.route('/login', methods =['GET','POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user:
            if bcrypt.check_password_hash(user.password, form.password.data):
                login_user(user)
                flash('Logged in!')
                return redirect(url_for('dash', user=user))
    return render_template('login.html',form=form)

@app.route('/signup', methods =['GET','POST'])
def signup():
    form = RegisterForm()

    if form.validate_on_submit():
        flash('Account Created!')
        hashed_pw = bcrypt.generate_password_hash(form.password.data)
        new_user = User(username=form.username.data, password=hashed_pw)
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('login'))


    return render_template('signup.html',form=form)

@app.route("/newpost", methods =['GET','POST'])
@login_required
def newpost():
    form = PostForm()
    if form.validate_on_submit():
        post = Post(title=form.title.data,content=form.content.data, author=current_user)
        db.session.add(post)
        db.session.commit()
        flash('Post Created!', 'success')
        return redirect(url_for('dash'))
    return render_template('posts.html', title ='New Post', form=form)

@app.route("/post/<int:post_id>/delete", methods=['POST'])
@login_required
def delete_post(post_id):
    post = Post.query.get_or_404(post_id)
    if post.author != current_user:
        abort(403)
    db.session.delete(post)
    db.session.commit()
    flash('Your post has been deleted!', 'success')
    return redirect(url_for('home'))

@app.route('/logout', methods=['GET','POST'])
@login_required
def logout():
    logout_user()
    return redirect(url_for('home'))




if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)
