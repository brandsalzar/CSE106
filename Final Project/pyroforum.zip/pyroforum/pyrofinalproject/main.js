
//Comment
function showComment(){
    var commentArea = document.getElementById("comment-area");
    commentArea.classList.remove("hide");
}

//Reply
function showReply(){
    var replyArea = document.getElementById("reply-area");
    replyArea.classList.remove("hide");
}
var counter = 0;
function upvote(){
 counter++;
 document.getElementById('votes').innerHTML = counter;
}
function downvote(){
 counter--;
 document.getElementById('votes').innerHTML = counter;
}

function displayVote(){
    print(counter);
}