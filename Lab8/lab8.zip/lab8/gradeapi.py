from flask import Flask, render_template, redirect, jsonify, request, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin,LoginManager, login_required, logout_user, login_user
from flask_admin import Admin
from flask_admin.contrib.sqla import ModelView


app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = 'sqlite:///grade.db'
SQLALCHEMY_TRACK_MODIFICATIONS = False
db = SQLAlchemy(app)
admin = Admin(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
app.secret_key = 'keep it secret, keep it safe'

@login_manager.user_loader
def load_user(user_id):
    return Users.query.get(int(user_id))

class Users(UserMixin, db.Model):
     id = db.Column(db.Integer, primary_key=True)
     username = db.Column(db.String, unique=True, nullable=False)
     password = db.Column(db.String, unique=False, nullable=False)

def __init__(self, username, password):
        self.username = username
        self.password = password

def check_password(self, password):
        return self.password == password


class Students(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, unique=False, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey(Users.id), nullable=False)
    studentEnrollment = db.relationship('Enrollment', backref='Students', lazy=True)

    def __init__(self, name, user_id):
        self.name = name
        self.user_id = user_id


class Teachers(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, unique=False, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey(Users.id), nullable=False)
    classes = db.relationship('Classes', backref='Teachers', lazy=True)

    def __init__(self, name, user_id):
        self.name = name
        self.user_id = user_id


class Classes(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    courseName = db.Column(db.String, unique=True, nullable=False)
    teacherName = db.Column(db.Integer, db.ForeignKey(Teachers.id), nullable=False)
    time = db.Column(db.String, unique=False, nullable=False)
    studEnrolled = db.Column(db.Integer, unique=False, nullable=False)
    classEnrolled = db.relationship('Enrollment', backref='Classes', lazy=True)

    def __init__(self, courseName, teacherName, time, studEnrolled):
        self.courseName = courseName
        self.teacherName = teacherName
        self.time = time
        self.studEnrolled = studEnrolled


class Enrollment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    class_id = db.Column(db.Integer, db.ForeignKey(Classes.id))
    student_id = db.Column(db.Integer, db.ForeignKey(Students.id))
    grade = db.Column(db.Integer, nullable=False)

    def __init__(self, user_id, class_id, student_id, grade):
        self.users_id = user_id
        self.class_id = class_id
        self.student_id = student_id
        self.grade = grade




db.create_all()

admin.add_view(ModelView(Users, db.session))
admin.add_view(ModelView(Students, db.session))
admin.add_view(ModelView(Teachers, db.session))
admin.add_view(ModelView(Classes, db.session))
admin.add_view(ModelView(Enrollment, db.session))


@app.route('/', methods = ["GET", "POST"])
def home():
    return render_template('login.html')
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == "POST" and 'username' in request.form and 'password' in request.form:
        data = request.get_json()

        user = Users.query.filter_by(username=data['username']).first()
        if user is None or not user.check_password(data['password']):
            return url_for('login')
        else:
            login_user(user)
            return redirect(url_for('student'))

@app.route('/teacher', methods=['GET'])
@login_required
def teacher():
    return render_template('teachers.html')

@app.route('/student', methods=['GET', 'POST'])
@login_required
def student():
    return render_template('student.html')

@app.route('/courses')
@login_required
def get_courses():
    courses = Classes.select()
    return render_template('courses.html', courses=courses)

@app.route('/register', methods=['POST'])
@ login_required
def register():
    new_user = Users(username=input(),password=())
    db.session.add(new_user)
    db.session.commit()
    return render_template('register.html')


@app.route('/logout', methods=['POST'])
@login_required
def logout():
    logout_user()
    return render_template('login.html')

if __name__ == '__main__':
        app.run(debug=True, host='127.0.0.1')